
const divs=document.
querySelectorAll("div");

const hr_block=document.querySelectorAll("div")[0];
const min_block=document.querySelectorAll("div")[1];
const sec_block=document.querySelectorAll("div")[2];
const stop = document.querySelectorAll("button")[0];
const resume = document.querySelectorAll('button')[1];
const lap=document.querySelector("button")[2];
const time_lap=document.querySelector('time_lap')
let audio= document.getElementsByTagName("audio");


stop.style.backgroundColor='red';
resume.style.backgroundColor='green';
resume.style.fontWeight='bold'
stop.style.fontWeight='bold'


let hours =0;
let minutes = 58;
let seconds =55;

min_block.textContent = minutes + "min"
hr_block.textContent=hours + "hr";
sec_block.textContent=seconds + "sec";

    let id;
id=setInterval(() => {
    if(seconds >= 59){
    min_block.textContent= ++minutes + "min";
seconds=0;
}
if(minutes >=59 ){
    hr_block.textContent = ++hours + "hr";
    minutes =0;
    seconds =0;
}

sec_block.textContent= ++seconds + "sec";
},1000 );


stop.addEventListener("click",()=>{
    clearInterval(id)
    
});

// resume.addEventListener('click',()=>{
// setTimeout=alert('hklahfkhffgjhfdagfjg')
// });
  
        



// lap.addEventListener('click',()=>{
//     let div=document.createElement("div");
//     div.textContent=`${hours}hr :${minutes}min : ${seconds}sec`;
//     time_lap.insertAdjacentElement()
// })

