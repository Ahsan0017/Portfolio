
const wreaper=document.querySelector('.wrapper');
const login_link=document.querySelector('.login-link');
const register_link=document.querySelector('.register-link');
const borderlogin=document.querySelector('.btnlogin-popup')
const close=document.querySelector('.icon-close')

register_link.addEventListener('click',()=>{
    wreaper.classList.add('active');
})

login_link.addEventListener('click',()=>{
    wreaper.classList.remove('active');
})
 
borderlogin.addEventListener('click',()=>{
    wreaper.classList.add('active-popup');
    setTimeout(() => {
        alert('Be carefully');
    }, 300);
})

close.addEventListener('click',()=>{
    wreaper.classList.remove('active-popup');
})

     

